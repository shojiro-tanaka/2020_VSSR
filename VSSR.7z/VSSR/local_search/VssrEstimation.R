# Execution Date: 20200102

rm(list=ls(all=TRUE))

load("../wide_range/allDataForRegression.rdata")

#nprov  <- 9                   # Number of provinces in Sumatra (exclude Riau islands)
#time   <- 7                   # Number of time period
#It     <- diag(time)

range = seq(0.710, 0.765, 0.0001)       
#range = seq(0.0, 0.9, 0.005)           
####################  Storage matrix for output #######################################
full   = matrix(1:length(range)*10, nrow=length(range), ncol=10)
select = matrix(1:length(range)*10, nrow=length(range), ncol=10)
id = 0

for (lambda in range){       
################## begin: loop lambda ###########################

Trans  =  diag(nprov) - lambda*W
A0     =  kronecker(It, Trans      )    # Transform W into NT x NT consists of diagonal block of Trans
A      =  kronecker(It, Trans %*% W)    # Transform W into NT x NT consists of diagonal block of W

# WY_all and WX_all
y_all  =  A0 %*% y_all_orig
X_all  =  A0 %*% X_all_orig
Wy_all <- A  %*% y_all_orig
WX_all <- A  %*% X_all_orig

colnames( y_all) <- c("income")
colnames( X_all) <- c( "growth",  "school",  "popgr",  "prod",  "mining",  "wsale",  "child.ratio")
colnames(Wy_all) <- c("Wincome")
colnames(WX_all) <- c("Wgrowth", "Wschool", "Wpopgr", "Wprod", "Wmining", "Wwsale", "Wchild_ratio")

###################  Adjust Term ################################
tTrans  <- diag(nprov) - lambda*t(W)
adjust  <- - time * log(det(tTrans %*% Trans))
#################################################################

lm1  = lm(y_all ~ Wy_all + X_all[,1]+ X_all[,2]+ X_all[,3]+ X_all[,4]+ X_all[,5]+ X_all[,6]+ X_all[,7]
                         +WX_all[,1]+WX_all[,2]+WX_all[,3]+WX_all[,4]+WX_all[,5]+WX_all[,6]+WX_all[,7])
p = 1 + 1 + 1 + 1 + 2*7                 # lambda, variance, common intercept, Wy, X beta, W X beta
mse  = sum(lm1$residuals^2)/ length(y_all)
mse2 = sum(lm1$residuals^2)/(length(y_all) - p + 2)
logL = - length(y_all) * (log(2*pi*exp(1)) + log(mse ))/2
logL2= - length(y_all) * (log(2*pi*exp(1)) + log(mse2))/2
AIC  = -2*logL + 2*p                  + adjust;
BIC  = -2*logL + log(length(y_all))*p + adjust;
sink( "local_fullModel.log", append=T ) 
cat(sprintf("lambda =%7.4f  mse =%8.5f  logL =%8.4f  mse2 =%8.5f  logL2 =%8.4f  p = %d  adjust =%8.4f  AIC =%7.5f  BIC =%8.5f\n", lambda, mse, logL, mse2, logL2, p, adjust, AIC, BIC) )
sink()

id = id + 1
full[id, ] = c(id, lambda, mse, logL, mse2, logL2, p, adjust, AIC, BIC)

sink( gsub(" ", "", paste( "./variableSelectionLogs/local", sprintf("%6.4f", lambda), ".log") ) )
lm1.step = step(lm1)
sink()
p    = 1 + 1 + lm1.step$rank            # lambda, variance, regressors
mse  = sum(lm1.step$residuals^2)/ length(y_all)
mse2 = sum(lm1.step$residuals^2)/(length(y_all) - p + 2)
logL = - length(y_all) * (log(2*pi*exp(1)) + log(mse ))/2
logL2= - length(y_all) * (log(2*pi*exp(1)) + log(mse2))/2
AIC  = -2*logL + 2*p                  + adjust;
BIC  = -2*logL + log(length(y_all))*p + adjust;
sink( "local_selectedmodel.log", append=T ) 
cat(sprintf("lambda =%7.4f  mse =%8.5f  logL =%8.4f  mse2 =%8.5f  logL2 =%8.4f  p = %d  adjust =%8.4f  AIC =%7.5f  BIC =%8.5f\n", lambda, mse, logL, mse2, logL2, p, adjust, AIC, BIC) )
sink()

select[id, ] = c(id, lambda, mse, logL, mse2, logL2, p, adjust, AIC, BIC)

rm(Trans, A0, A, y_all, X_all, Wy_all, WX_all, lm1)
############## end loop: lambda##################################
} ### end
#################################################################

windows()
plot(full[,2], full[,9], type="l", xlab="", ylab="", col="red", xlim=c(0.70,0.77), ylim=c(46, 57), main="Full and Selected Models")
par(new=T)
plot(select[,2], select[,9], type="l", xlab="lambda", ylab="AIC", xlim=c(0.70,0.77), ylim=c(46, 57), main="")


#bitmap("AIC-localRange.bmp") 
pdf("AIC-localRange.pdf")
plot(full[,2], full[,9], type="l", xlab="", ylab="", col="red", xlim=c(0.70,0.77), ylim=c(46, 57), main="Full and Selected Models")
par(new=T)
plot(select[,2], select[,9], type="l", xlab="lambda", ylab="AIC", xlim=c(0.70,0.77), ylim=c(46, 57), main="")

full[which.min(full[,9]),]
select[which.min(select[,9]),]

save(full, select, file="localRangeEstimates.Rdata")

dev.off()
closeAllConnections()

# Best full   model lambda = 0.7210, p = 18,  AIC = 55.40826588  # check and confirmed 20191020 by S. Tanaka
# Best select model lambda = 0.7543, p = 13,  AIC = 47.84450027  # check and confirmed 20191020 by S. Tanaka

