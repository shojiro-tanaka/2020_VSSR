(c) 2020 Ryuei Nishii, Shojiro Tanaka, and Gigih Fitrianto ( GPL >= 2 )
  Sumatra data by Gigih Fitrianto
  VSSR method invention by Ryuel Nishii
  Program codes by Shojiro Tanaka, Ryuei Nishii, and Gigih Fitrianto
