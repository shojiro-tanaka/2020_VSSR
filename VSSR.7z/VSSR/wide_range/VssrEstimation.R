# Execution Date: 20200102

rm(list=ls(all=TRUE))

income.r <- read.csv("../data/ID_Average Wage.csv")        # Average income per month by laborer
gr.r     <- read.csv("../data/ID_Growth per capita.csv")   # GRP growth per capita
school.r <- read.csv("../data/ID_School.csv")              # Gross secondary school enrollment ratio
popgr.r  <- read.csv("../data/ID_Pop Growth.csv")          # Population growth
prod.r   <- read.csv("../data/ID_Palm Oil.csv")            # Crude palm oil production
mining.r <- read.csv("../data/ID_Mining.csv")              # Mining sector's output (in Rupiahs)
wsale.r  <- read.csv("../data/ID_Wholesale.csv")           # Wholesale and retail sector's output (in Rupiahs)
labor.r  <- read.csv("../data/ID_Labor.csv")               # Number of Laborer as denominator for per labor unit
popul.r  <- read.csv("../data/ID_Population.csv")          # Population
child.r  <- read.csv("../data/ID_Child.csv")               # Child Population
# -------------------------------------- #

# Prepare the Data in N x T data structure
# Crop the data only for Provinces in Sumatra

nprov  <- 9                   # Number of provinces in Sumatra (exclude Riau islands)
time   <- 7                   # Number of time period

income <- as.matrix(income.r[1:nprov,2:ncol(income.r)])
gr     <- as.matrix(gr.r[    1:nprov,2:ncol(gr.r    )])
school <- as.matrix(school.r[1:nprov,2:ncol(school.r)])
popgr  <- as.matrix(popgr.r[ 1:nprov,2:ncol(popgr.r )])
labor  <- as.matrix(labor.r[ 1:nprov,2:ncol(labor.r )])
popul  <- as.matrix(popul.r[ 1:nprov,2:ncol(popul.r )])
child  <- as.matrix(child.r[ 1:nprov,2:ncol(child.r )])
prod   <- as.matrix(prod.r[  1:nprov,2:ncol(prod.r  )])
prod   <- prod/labor          # Palm Oil per Labor Data

mining <- as.matrix(mining.r[1:nprov,2:ncol(mining.r)])
mining <- mining/labor        # Mining per Labor Data

wsale  <- as.matrix(wsale.r[1:nprov,2:ncol(wsale.r)])
wsale  <- wsale/labor         # Wholesale per Labor Data

child_ratio <- child/popul    # Children per Population

rm(income.r, gr.r, school.r, popgr.r, prod.r, 
   mining.r, wsale.r, labor.r)                    # Remove the raw data
# -------------------------------------- #

# Normalize the Data
# y = Income
y.r <- c(income)     
y   <- (y.r - mean(y.r))/sd(y.r)       # Normalized the data

# Comparison transformed y[1:9] and income[,1]

# y.r[1:9]
# [1] 1510050 1431450 1664550 1760550 1354700 1388500 1466550 1099900 1519300

# income[,1]
#       1       2       3       4       5       6       7       8       9 
# 1510050 1431450 1664550 1760550 1354700 1388500 1466550 1099900 1519300

# x1 = GRP growth per capita
x1.r <- c(gr)                           # N x T into NT x 1
x1   <- (x1.r - mean(x1.r))/sd(x1.r)    # Normalized the data

# x2 = Secondary school enrollment ratio
x2.r <- c(school)                       # N x T into NT x 1
x2   <- (x2.r - mean(x2.r))/sd(x2.r)    # Normalized the data

# x3 = Population Growth
x3.r <- c(popgr)                        # N x T into NT x 1
x3   <- (x3.r - mean(x3.r))/sd(x3.r)    # Normalized the data

# x4 = Crude Palm Oil Production per Labor 
x4.r <- c(prod)                         # N x T into NT x 1
x4   <- (x4.r - mean(x4.r))/sd(x4.r)    # Normalized the data

# x5 = Mining per Labor
x5.r <- c(mining)                       # N x T into NT x 1
x5   <- (x5.r - mean(x5.r))/sd(x5.r)    # Normalized the data

# x6 = Wholesale and Retail per Labor
x6.r <- c(wsale)                        # N x T into NT x 1
x6   <- (x6.r - mean(x6.r))/sd(x6.r)    # Normalized the data

# x7 = labor per population
#x7.r <- c(l_p_ratio)                   # N x T into NT x 1
#x7   <- (x7.r - mean(x7.r))/sd(x7.r)   # Normalized the data

# x7 = labor per population
x7.r <- c(child_ratio)                  # N x T into NT x 1
x7   <- (x7.r - mean(x7.r))/sd(x7.r)    # Normalized the data


rm(y.r, x1.r, x2.r, x3.r, x4.r, x5.r, x6.r, x7.r)
# -------------------------------------- #

# y_all and X_all
y_all_orig <- matrix(y, ncol = 1)
X_all_orig <- cbind(x1,x2,x3,x4,x5,x6,x7)

# Spatial W Matrix
W.b      <- read.csv("../data/W Indonesia 1.csv", 
                     header = F)                  # wij = 1 if shares common border
W        <- (1/rowSums(W.b))*W.b                  # Manually row-standardized 
W        <- as.matrix(W[1:nprov,1:nprov])
W[9,]    <- 0                                     # For Bangka Belitung province (separated Island)

It     =  diag(time)

#################################################################
eig <- eigen(W)
maxEigInv <- 1/max(eig$values)          # 1
minEigInv <- 1/min(eig$values)          # -1.3828
rm(eig)
#################################################################

range = seq(0.0, 0.9, 0.005)           
####################  Storage matrix for output #######################################
full   = matrix(1:length(range)*10, nrow=length(range), ncol=10)
select = matrix(1:length(range)*10, nrow=length(range), ncol=10)
id = 0

for (lambda in range){       
################## begin: loop lambda ###########################

Trans  =  diag(nprov) - lambda*W
A0     =  kronecker(It, Trans      )    # Transform W into NT x NT consists of diagonal block of Trans
A      =  kronecker(It, Trans %*% W)    # Transform W into NT x NT consists of diagonal block of W

# WY_all and WX_all
y_all  =  A0 %*% y_all_orig
X_all  =  A0 %*% X_all_orig
Wy_all <- A  %*% y_all_orig
WX_all <- A  %*% X_all_orig

colnames( y_all) <- c("income")
colnames( X_all) <- c( "growth",  "school",  "popgr",  "prod",  "mining",  "wsale",  "child.ratio")
colnames(Wy_all) <- c("Wincome")
colnames(WX_all) <- c("Wgrowth", "Wschool", "Wpopgr", "Wprod", "Wmining", "Wwsale", "Wchild_ratio")

###################  Adjust Term ################################
tTrans  <- diag(nprov) - lambda*t(W)
adjust  <- - time * log(det(tTrans %*% Trans))
#################################################################

lm1  = lm(y_all ~ Wy_all + X_all[,1]+ X_all[,2]+ X_all[,3]+ X_all[,4]+ X_all[,5]+ X_all[,6]+ X_all[,7]
                         +WX_all[,1]+WX_all[,2]+WX_all[,3]+WX_all[,4]+WX_all[,5]+WX_all[,6]+WX_all[,7])
p = 1 + 1 + 1 + 1 + 2*7                 # lambda, variance, common intercept, Wy, X beta, W X beta
mse  = sum(lm1$residuals^2)/ length(y_all)
mse2 = sum(lm1$residuals^2)/(length(y_all) - p + 2)
logL = - length(y_all) * (log(2*pi*exp(1)) + log(mse ))/2
logL2= - length(y_all) * (log(2*pi*exp(1)) + log(mse2))/2
AIC  = -2*logL + 2*p                  + adjust;
BIC  = -2*logL + log(length(y_all))*p + adjust;
sink( "wide_fullModel.log", append=T ) 
cat(sprintf("lambda =%7.4f  mse =%8.5f  logL =%8.4f  mse2 =%8.5f  logL2 =%8.4f  p = %d  adjust =%8.4f  AIC =%7.5f  BIC =%8.5f\n", lambda, mse, logL, mse2, logL2, p, adjust, AIC, BIC) )
sink()

id = id + 1
full[id, ] = c(id, lambda, mse, logL, mse2, logL2, p, adjust, AIC, BIC)

sink( gsub(" ", "", paste( "./variableSelectionLogs/wide", sprintf("%6.4f", lambda), ".log") ) )
lm1.step = step(lm1)
sink()
p    = 1 + 1 + lm1.step$rank            # lambda, variance, regressors
mse  = sum(lm1.step$residuals^2)/ length(y_all)
mse2 = sum(lm1.step$residuals^2)/(length(y_all) - p + 2)
logL = - length(y_all) * (log(2*pi*exp(1)) + log(mse ))/2
logL2= - length(y_all) * (log(2*pi*exp(1)) + log(mse2))/2
AIC  = -2*logL + 2*p                  + adjust;
BIC  = -2*logL + log(length(y_all))*p + adjust;
sink( "wide_selectedmodel.log", append=T ) 
cat(sprintf("lambda =%7.4f  mse =%8.5f  logL =%8.4f  mse2 =%8.5f  logL2 =%8.4f  p = %d  adjust =%8.4f  AIC =%7.5f  BIC =%8.5f\n", lambda, mse, logL, mse2, logL2, p, adjust, AIC, BIC) )
sink()

select[id, ] = c(id, lambda, mse, logL, mse2, logL2, p, adjust, AIC, BIC)

rm(Trans, A0, A, y_all, X_all, Wy_all, WX_all, lm1)
############## end loop: lambda##################################
} ### end
#################################################################

windows()
plot(full[,2], full[,9], type="l", xlab="", ylab="", col="red", xlim=c(0,0.9), ylim=c(46, 72), main="Full and Selected Models")
par(new=T)
plot(select[,2], select[,9], type="l", xlab="lambda", ylab="AIC", xlim=c(0,0.9), ylim=c(46, 72), main="")


#bitmap("AIC-WideRange.bmp") 
pdf("AIC-WideRange.pdf")
plot(full[,2], full[,9], type="l", xlab="", ylab="", col="red", xlim=c(0,0.9), ylim=c(46, 72), main="Full and Selected Models")
par(new=T)
plot(select[,2], select[,9], type="l", xlab="lambda", ylab="AIC", xlim=c(0,0.9), ylim=c(46, 72), main="")

full[which.min(full[,9]),]
select[which.min(select[,9]),]

save(full, select, file="wideRangeEstimates.Rdata")
save(nprov, time, It, y_all_orig, X_all_orig, W, file="allDataForRegression.Rdata")

dev.off()
closeAllConnections()

# Jump at lambda = 0.5708 (p = 14, AIC = 51.082) to 0.5709 (p = 13, AIC = 51.079)