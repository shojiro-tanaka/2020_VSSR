rm(list=ls(all=TRUE))

load("wideRangeEstimates.rdata")
windows()
plot(common_full[,2], common_full[,9], type="l", xlab="", ylab="", col="red", xlim=c(0,0.9), ylim=c(46, 72), main="Full and Selected Models")
par(new=T)
plot(common_best[,2], common_best[,9], type="l", xlab="lambda", ylab="AIC", xlim=c(0,0.9), ylim=c(46, 72), main="")

#bitmap("AIC-WideRange.bmp") 
pdf("AIC-WideRange.pdf")
plot(full[,2], full[,9], type="l", xlab="", ylab="", col="red", xlim=c(0,0.9), ylim=c(46, 72), main="Full and Selected Models")
par(new=T)
plot(best[,2], best[,9], type="l", xlab="lambda", ylab="AIC", xlim=c(0,0.9), ylim=c(46, 72), main="")



dev.off()
closeAllConnections()
